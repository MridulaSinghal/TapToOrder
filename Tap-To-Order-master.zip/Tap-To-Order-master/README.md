A Smart Stock Monitoring System, based on IoT, for the automation of inventory management in industries to reduce stockouts,human error and increase profits and personal efficiency.  
Pl consider only the following files in the repository,
1.details2.zip
2.login.zip
3.http.ino
4.cog.php



mqtt.ino is the file where we have sent the data to the cloud using mqtt protocol;


css,css_pirobox, images are the formattings for 1.html;


http.ino is the file where we have sent the data to the cloud using http protocol (faster and less error prone compared to mqtt);

details2 , login contains rest of the web pages;

cog.php is the file which we have tried to use the face cognitive feature .


